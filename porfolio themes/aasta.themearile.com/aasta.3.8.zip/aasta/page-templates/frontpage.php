<?php
/**
 * Template Name: Frontpage
 *
 * Displays the Home page.
 *
 * @package aasta
 */
?>

<?php

get_header(); 

do_action( 'arilesuper_aasta_frontpage', false);
	
?>
<?php get_footer(); ?>
